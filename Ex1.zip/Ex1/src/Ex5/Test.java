package Ex5;

public class Test {
	public static void main(String[] args) {
		int [] array = {1,2,3,4,5,6,2,2};
		System.out.println("Số lần xuất hiện là " + Ex5.duplicateTimes(array, 2));
	}
}
