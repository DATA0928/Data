package Ex1;

public class Ex1 {
	public static int[] thayThe(int[] array, int position1, int position2) {
		int temp = 0;
		for (int i = 0; i < array.length; i++) {
			temp = array[position1];
			array[position1] = array[position2];
			array[position2] = temp;
		}
		return array;
	}
}
