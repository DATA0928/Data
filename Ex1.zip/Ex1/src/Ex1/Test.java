package Ex1;
import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		int [] array = {1,2,3,4,5};
		System.out.println(Arrays.toString(Ex1.thayThe(array, 0, 1)));
	}
}
