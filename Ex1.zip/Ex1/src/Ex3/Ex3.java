package Ex3;

public class Ex3 {
	public static int[] insert(int[] array, int position, int value){
	
		for (int i = 0 ; i < array.length ; i ++) {
			if(i==position) {
				array[i]=value;
			}
		}
	
		return array;
	}
}
