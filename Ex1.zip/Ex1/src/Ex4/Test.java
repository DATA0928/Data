package Ex4;

public class Test {
	public static void main(String[] args) {
		int [] array = {1,2,3,4,5};
		System.out.println("Mảng trước khi đổi là: ");
		Ex4.printArray(array);
		System.out.println();
		System.out.println("Mảng sau khi đổi là: ");
		Ex4.reverse(array);
	}
}
