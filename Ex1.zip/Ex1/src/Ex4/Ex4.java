package Ex4;

public class Ex4 {
	public static void reverse(int[] array) {
		int count = 0;
		int[] arr = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			arr[i] = array[array.length -1- count];
			count++;
		}
		for (int i = 0 ; i < array.length ; i++) {
			System.out.print(arr[i] + " ");
		}

	}
	
	public static void printArray(int [] array) {
		for (int i = 0 ; i < array.length ; i++) {
			System.out.print(array[i] + " ");
		}
	}
}
