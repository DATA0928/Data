package Ex2;

public class Ex2 {
	public static int[] delete(int[] array, int position){
		int j = 0;
		int [] arr = new int [array.length-1];
		for (int i = 0 ; i < array.length; i ++) {
			if(i!=position) {
				arr[j]=array[i];
				j++;
			}
		}
		return arr;
	
	}
}
