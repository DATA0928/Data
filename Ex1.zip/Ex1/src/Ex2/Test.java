package Ex2;

import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		int [] array = {1,2,3,4,5};
		System.out.println(Arrays.toString(Ex2.delete(array, 3)));
	}
}
