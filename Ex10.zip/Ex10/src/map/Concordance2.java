package map;

import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.ArrayList;

public class Concordance2 {

    // Phương thức xây dựng concordance từ danh sách các dòng văn bản
    public static HashMap<String, Integer> buildConcordance(ArrayList<String> lines) {
        // Tạo một HashMap để lưu trữ concordance
        HashMap<String, Integer> concordance = new HashMap<>();

        // Duyệt qua từng dòng văn bản
        for (String line : lines) {
            // Sử dụng StringTokenizer để chia dòng thành các từ
            StringTokenizer parser = new StringTokenizer(line, " ,.;:-!?()");
            
            // Duyệt qua từng từ trong dòng
            while (parser.hasMoreTokens()) {
                // Lấy từ tiếp theo và chuyển về chữ thường để không phân biệt chữ hoa, chữ thường
                String word = parser.nextToken().toLowerCase();

                // Nếu từ đã có trong concordance, tăng giá trị tương ứng lên 1
                if (concordance.containsKey(word)) {
                    concordance.put(word, concordance.get(word) + 1);
                } else {
                    // Nếu từ chưa có trong concordance, thêm vào với giá trị là 1
                    concordance.put(word, 1);
                }
            }
        }

        // Trả về concordance đã xây dựng
        return concordance;
    }

    public static void main(String[] args) {
        // Đọc nội dung từ tập tin và lưu vào danh sách các dòng
        ArrayList<String> lines = FileUtils.readFile("./src/JingleBell.txt");

        // Xây dựng concordance từ danh sách các dòng
        HashMap<String, Integer> concordance = buildConcordance(lines);

        // In ra màn hình các từ và số lần xuất hiện tương ứng trong concordance
        for (String word : concordance.keySet()) {
            System.out.println(word + ": " + concordance.get(word) );
        }
    }
}

