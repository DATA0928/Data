package map;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Dictionary {
	private Map<String, String> mapEnglish = new TreeMap<String, String>();
	private Map<String, String> mapVietNam = new TreeMap<String, String>();
	
	public Dictionary(Map<String, String> map) {
		this.mapEnglish = map;
	}

	public void addWord(String key , String value) {
		mapEnglish.put(key, value);
		mapVietNam.put(value, key);
	}
	
	public String meanWord(String key) {
		return mapEnglish.get(key);
	}
	
	public String findEnglishToVietNam(String key) {
		return meanWord(key);
	}
	
	public String findVietNamToEnglish(String value) {
		return mapVietNam.get(value);
	}
	
	
	// Tìm kiếm gần đúng sử dụng foreach
    public Set<Map.Entry<String, String>> searchStartingWith(String prefix) {
        // Danh sách tạm thời chứa các entry thỏa mãn điều kiện
        Set<Map.Entry<String, String>> resultEntries = new HashSet<>();

        // Sử dụng foreach để duyệt qua tất cả các entry
        for (Map.Entry<String, String> entry : mapEnglish.entrySet()) {
            if (entry.getKey().startsWith(prefix)) {
                resultEntries.add(entry);
            }
        }

        return resultEntries;
    }


	public static void main(String[] args) {
	
		Map<String, String> map = new TreeMap<String, String>();
		Dictionary d1 = new Dictionary(map);
		d1.addWord("telephone","điện thoại");
		d1.addWord("motor", "xe máy");
		
		for (Map.Entry<String, String> bando : map.entrySet()) {
			System.out.println("key = " + bando.getKey() + "   value = " + bando.getValue());
		}
		
		System.out.println("Ý nghĩa của telephone là " + d1.meanWord("telephone"));
		System.out.println("Ý nghĩa của motor là " + d1.meanWord("motor"));
		
		d1.addWord("windown","cửa sổ");
		d1.addWord("table", "cái bảng");
		d1.addWord("color", "màu sắc");
		d1.addWord("movie", "xem phim");
		
		for (Map.Entry<String, String> bando : map.entrySet()) {
			System.out.println("key = " + bando.getKey() + "   value = " + bando.getValue());
		}
		System.out.print("Test phương thức findEnglishToVietNam với key là windown thì value là");
		System.out.println(" "+ d1.findEnglishToVietNam("windown"));
		
		System.out.print("Test phương thức findVietNamToEnglish với value là màu sắc thì key là ");
		System.out.println(d1.findVietNamToEnglish("màu sắc"));
		
		System.out.println("Test phương thức tìm kiếm với từ gợi ý t");
		System.out.println(d1.searchStartingWith("m"));
		
	}
	

}
