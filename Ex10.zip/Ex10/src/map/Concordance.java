package map;

import java.util.Map;
import java.util.TreeMap;

public class Concordance {
	public Map<String, Integer> generateConcordance(String string){
		Map<String,Integer> concordanceMap = new TreeMap<>();
		String [] words = string.split("\\s+"); // cắt chuỗi bằng dấu cách
		for (String word : words) {
			String cleanedWord = word.replaceAll("[^a-zA-Z0-9]", ""); // loại bỏ các dấu câu 
																// chỉ giữ lại chữ số và chữ cái
			
		// chuyển tất cả về chữ thường để không cần phân biệt hoa/thường
			cleanedWord = cleanedWord.toLowerCase();
			
		//kiểm tra xem trong map có cleanedWord hay chưa
			if(concordanceMap.containsKey(cleanedWord)) {
				// Nếu có, thêm cleanedWord vào và tăng số lượng lên +1
				concordanceMap.put(cleanedWord, concordanceMap.get(cleanedWord) + 1);
			}else {
				// Nếu chưa, thêm cleanedWord vào map với số lượng là 1
				concordanceMap.put(cleanedWord, 1);
			}
		
		}
		return concordanceMap;
	}
	
	public static void main(String[] args) {
		Concordance c1 = new Concordance();
		Map<String, Integer> map = c1.generateConcordance("Love    My  !love my Dog?  ");
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			System.out.println("Key = " + entry.getKey() + "   Value = " + entry.getValue() );
		}
	}
}
