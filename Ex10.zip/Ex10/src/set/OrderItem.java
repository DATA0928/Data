package set;

public class OrderItem implements Comparable<OrderItem> {
	private String id;
	private String nameItem; // tên mặt hàng
	private int unitPrice; // đơn giá
	private int quantity; // số lượng

	public OrderItem(String id, String nameItem, int unitPrice, int quantity) {
		this.id = id;
		this.nameItem = nameItem;
		this.unitPrice = unitPrice;
		this.quantity = quantity;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNameItem() {
		return nameItem;
	}

	public void setNameItem(String nameItem) {
		this.nameItem = nameItem;
	}

	public int getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(int unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getQuantity() {
		return quantity;
	}

	

	@Override
	public String toString() {
		return "id= " + id + ", nameItem= " + nameItem + ", unitPrice= " + unitPrice + ", quantity= " + quantity
				+ "\n";
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	//khác nhau dựa trên những cái dòng (id)
	// để sắp xếp giảm dần thi mình nhân -1
	@Override
	public int compareTo(OrderItem o) {
		return this.getId().compareTo(o.getId());
		
	}
	
}
