package set;

import java.util.TreeSet;

public class Order {
	private String customerName;
	private OrderItem orderItem;
	private TreeSet<OrderItem> pack = new TreeSet<OrderItem>();

	public Order(String customerName, TreeSet<OrderItem> pack) {
		this.customerName = customerName;
		this.pack = pack;
	}

	public String getCustomerName() {
		return customerName;
	}

	@Override
	public String toString() {
		String result = "";
		for (OrderItem orderItem : pack) {
			result += orderItem;
		}
		return result;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public TreeSet<OrderItem> getPack() {
		return pack;
	}

	public void setPack(TreeSet<OrderItem> pack) {
		this.pack = pack;
	}

	public void addOrderItem(OrderItem o1) {
		pack.add(o1);
	}

	public void removeOrderItem(OrderItem o1) {
		pack.remove(o1);
	}

	public OrderItem findName(String name) {
		for (OrderItem orderItem : pack) {
			if (orderItem.getNameItem().equalsIgnoreCase(name)) {
				return orderItem;
			}
		}
		return null; // Trả về null nếu không tìm thấy
	}

	public OrderItem findNumber(int num) {
		for (OrderItem orderItem : pack) {
			if (orderItem.getQuantity() > num) {
				return orderItem;
			}
		}
		return null;
	}

	public void addSpecial(OrderItem o1) {
		boolean found = false;

		// Duyệt qua tất cả các OrderItem trong TreeSet
		for (OrderItem orderItem : pack) {
			// Nếu tìm thấy OrderItem có tên giống nhau (không phân biệt chữ hoa/chữ thường)
			if (orderItem.getNameItem().equalsIgnoreCase(o1.getNameItem())) {
				// Tạo một OrderItem mới với thông tin cập nhật về số lượng
				OrderItem newOrderItem = new OrderItem(orderItem.getId(), orderItem.getNameItem(),
						orderItem.getUnitPrice(), orderItem.getQuantity() + o1.getQuantity());

				// Xóa OrderItem cũ từ TreeSet và thêm OrderItem mới
				pack.remove(orderItem);
				pack.add(newOrderItem);

				// Đánh dấu là đã tìm thấy OrderItem và thoát khỏi vòng lặp
				found = true;
				break;
			}
		}

		// Nếu không tìm thấy OrderItem nào giống, thêm OrderItem mới vào TreeSet
		if (!found) {
			pack.add(o1);
		}
	}

	public void removeSpecial(OrderItem o1) {
		boolean found = false;

		// Duyệt qua tất cả các OrderItem trong TreeSet
		for (OrderItem orderItem : pack) {
			// Nếu tìm thấy OrderItem có tên giống nhau (không phân biệt chữ hoa/chữ thường)
			if (orderItem.getNameItem().equalsIgnoreCase(o1.getNameItem())) {
				// Tạo một OrderItem mới với thông tin cập nhật về số lượng
				OrderItem newOrderItem = new OrderItem(orderItem.getId(), orderItem.getNameItem(),
						orderItem.getUnitPrice(), orderItem.getQuantity() - o1.getQuantity());
				if (orderItem.getQuantity() - o1.getQuantity() < 0) {
					System.out.println("Lỗi");
				}
				// Xóa OrderItem cũ từ TreeSet và thêm OrderItem mới
				pack.remove(orderItem);
				pack.add(newOrderItem);

				// Đánh dấu là đã tìm thấy OrderItem và thoát khỏi vòng lặp
				found = true;
				break;
			}
		}

		// Nếu không tìm thấy OrderItem nào giống, thêm OrderItem mới vào TreeSet
		if (!found) {
			pack.add(o1);
		}
	}

	public OrderItem returnItem(char character) {
		for (OrderItem orderItem : pack) {
			StringBuilder str = new StringBuilder(orderItem.getNameItem());
			char k = str.charAt(0);
			if (k == character) {
				return orderItem;
			}

		}
		return null;

	}

	public int sumMoney() {
		int sum = 0;
		for (OrderItem orderItem : pack) {
			sum += orderItem.getUnitPrice() * orderItem.getQuantity();
		}
		return sum;
	}

//	public String toString() {
//		String result = "";
//		for (OrderItem orderItem : pack) {
//			result += orderItem;
//		}
//		return result;
//	}
	public String bill() {
		String result = "";
		for (OrderItem orderItem : pack) {
			result += orderItem + (orderItem.getUnitPrice() * orderItem.getQuantity() + "") + "\n" ;
		}
		return result + "/n" + "Tổng tiền của bạn là: "+ sumMoney();
	}

	public static void main(String[] args) {
		OrderItem o1 = new OrderItem("1", "xà bông OMO", 32000, 2);
		OrderItem o2 = new OrderItem("2", " dầu ăn simply", 51000, 1);
		OrderItem o3 = new OrderItem("3", "đường cát trắng", 23000, 4);
		TreeSet<OrderItem> pack = new TreeSet<>();
		pack.add(o1);
		pack.add(o2);
		pack.add(o3);

		System.out.println("Chạy thử");
		for (OrderItem orderItem : pack) {
			System.out.println(orderItem.toString());
		}

		OrderItem o4 = new OrderItem("4", "nước rửa chén", 18000, 1);
		OrderItem o5 = new OrderItem("5", "hạt nêm AJ ngon", 9000, 2);

		pack.add(o4);
		pack.add(o5);

		System.out.println("Test phương thức add o4,o5");
		Order order1 = new Order("Nguyen Thi Thu Van", pack);
		System.out.println(order1.toString());

		System.out.println("-----------");

		System.out.println("Test phương thức remove o1");
		pack.remove(o1);
		System.out.println(order1.toString());

		System.out.println("Test phương thức findName");
		System.out.println(order1.findName("đường cát trắng"));
		System.out.println(order1.findName("hạt nêm AJ ngon"));
		System.out.println("Test phương thức findNumber");
		System.out.println(order1.findNumber(2));

		System.out.println("-------------");
		OrderItem o6 = new OrderItem("3", "đường cát trắng", 23000, 4);
		OrderItem o7 = new OrderItem("7", "kem đánh răng P/S", 28000, 1);

		order1.setPack(pack); // cập nhật lại order1

		System.out.println("Test phương thức thêm o6 và o7");
		order1.addSpecial(o6);
		order1.addSpecial(o7);
		System.out.println(order1.toString());

		OrderItem o8 = new OrderItem("8", "đường vàng", 25000, 3);
		pack.add(o8);
		order1.setPack(pack); // cập nhật lại order1
		System.out.println(order1.toString());
		System.out.println("Test phương thức returnItem");
		System.out.println(order1.returnItem('đ'));

		System.out.print("Tổng tiền của bạn là: ");
		System.out.println(order1.sumMoney() + " VND");

		System.out.println("Test phương thức removeSpecial");
		order1.removeSpecial(o3);
		System.out.println(order1.toString());
		System.out.print("Tổng tiền của bạn là: ");
		System.out.println(order1.sumMoney() + " VND");
		
		System.out.println("----------------");

		System.out.println("Test phương thức tính bill");
		System.out.println(order1.bill());
	}

}
