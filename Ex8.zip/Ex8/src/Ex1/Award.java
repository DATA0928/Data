package Ex1;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

import javax.management.RuntimeErrorException;

public class Award {
	private ArrayList<Customer> list = new ArrayList<>();

	public Award(String url) {
		this.list = loadCustomerList(url);
	}
	
	private ArrayList<Customer> loadCustomerList(String url){
		ArrayList<Customer> result = new ArrayList<Customer>();
		ArrayList<String> lines = FileUtils.readFile(url);
		// Lấy tung dong bien thanh customer bo vào danh sách trả về
		for (String line : lines) {
			StringTokenizer tokens = new StringTokenizer(line,"\t");
			String fullName = "";
			int score = 0;
			String idSuperMarket = "";
			int colNum =1;
			while (tokens.hasMoreElements()) {
				switch(colNum) {
				case 1:
					fullName = tokens.nextToken();
					break;
				case 2:
					score = Integer.parseInt(tokens.nextToken());
					break;
				case 3:
					idSuperMarket = tokens.nextToken();
					break;
				}
				colNum ++;
			}
			Customer cus = new Customer(fullName, score, idSuperMarket);
			result.add(cus);
		}
		return result;
	}

	@Override
	public String toString() {
		String result = "fullName\t|\tscore\t|\tsuperMarketID" + "\n";
		for (Customer c : this.list) {
			result += c + "\n";
			}
		return result;
		}
	
	public ArrayList<Customer> getRandomLuckyCustomer (int numCus){
		ArrayList<Customer> result  = new ArrayList<>();
		if(numCus < list.size()) {
			while (numCus >= 0) {
				int random = randomInt();
				Customer tmp = list.get(random);
				if(!result.contains(tmp)) {
					result.add(tmp);
					numCus -- ;
				}
			}
		}else {
			throw new RuntimeException("Over nize of list");
		}
		return result;
	}

	private int randomInt() {
		Random  n = new Random();
		return n.nextInt(list.size());
	}
	
	public static void main(String[] args) {
		Award award = new Award("./src/dsdt.txt");
		System.out.println(award);
	}
}
