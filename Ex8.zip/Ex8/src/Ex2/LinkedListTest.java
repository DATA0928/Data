package Ex2;

import java.util.LinkedList;

public class LinkedListTest {
	public static void main(String[] args) {
		LinkedList<Integer> test = new LinkedList<Integer>();
		// add không có gì là addLast
		test.add(5);
		test.addFirst(4);
		test.remove();
		test.addLast(9);
		test.add(1,5); // ở vị trí 1 add con số 5 vô
		test.add(null);
		
		System.out.println(test);
		
	}
}
