package ex2;

import java.util.Arrays;

public class Ex2 {
	public static void swap(int [] array, int i , int j) {
		int temp = array[i];
		array[i] = array[j];
		array[j] = temp;
	}
	public static int [] selectionSortMin(int [] array) {
		for (int i = 0 ; i < array.length -1 ; i ++) {
			for (int j = i + 1 ; j < array.length ; j++) {
				if(array[i] > array[j]) {
					swap(array, i, j);
				}
			}
		}
		return array;
	}	
	
	public static String printArray(int [] array) {
		return Arrays.toString(array);
	}
	public static String printArray2(char [] array) {
		return Arrays.toString(array);
	}
	public static void bubbleSort(char[] array) {
	    int n = array.length;
	    for (int i = 0; i < n - 1; i++) {
	        for (int j = 0; j < n - i - 1; j++) {
	            if (array[j] > array[j + 1]) {
	                // Swap array[j] and array[j + 1]
	                char temp = array[j];
	                array[j] = array[j + 1];
	                array[j + 1] = temp;
	            }
	        }
	    }
	}
	
	
	public static int[] insertionSort(int[] array) {
	    for (int i = 1; i < array.length; i++) {
	        int j = i - 1;
	        int temp = array[i];
	        while (j >= 0 && temp < array[j]) {
	            array[j + 1] = array[j];
	            j--;
	        }
	        array[j + 1] = temp;
	    }
	    return array;
	}


	
	public static void main(String[] args) {
		int [] array = {10,9,-10,-8,7,6,0};
		char [] arr = {'O','M','A','S','U','K','T'};
		int [] array1 = {5,3,7,-4,-9,0};
		
		System.out.println("Mảng trước khi sắp xếp là " + printArray(array));
		selectionSortMin(array);
		System.out.println("Mảng sau khi sắp xếp là " + printArray(array));
		System.out.println("-------------");

		System.out.println("Mảng trước khi sắp xếp là " + printArray2(arr));
		bubbleSort(arr);
		System.out.println("Mảng sau khi sắp xếp là " + printArray2(arr));
		System.out.println("-------------");
		
		System.out.println("Mảng trước khi sắp xếp là " + printArray(array1));
		insertionSort(array1);
		System.out.println("Mảng sau khi sắp xếp là " + printArray(array1));
	}
}
