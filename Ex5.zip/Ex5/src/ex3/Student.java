package ex3;

import java.util.Objects;

public class Student {
	
	private String id;
	private String fullName;
	private String academicYear;
	private double math;
	private double chemistry;
	private double physic;
	public Student(String id, String fullName, String academicYear, double math, double chemistry, double physic) {
		this.id = id;
		this.fullName = fullName;
		this.academicYear = academicYear;
		this.math = math;
		this.chemistry = chemistry;
		this.physic = physic;
	}
	@Override
	public int hashCode() {
		return Objects.hash(academicYear, chemistry, fullName, id, math, physic);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(academicYear, other.academicYear)
				&& Double.doubleToLongBits(chemistry) == Double.doubleToLongBits(other.chemistry)
				&& Objects.equals(fullName, other.fullName) && Objects.equals(id, other.id)
				&& Double.doubleToLongBits(math) == Double.doubleToLongBits(other.math)
				&& Double.doubleToLongBits(physic) == Double.doubleToLongBits(other.physic);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getAcademicYear() {
		return academicYear;
	}
	public void setAcademicYear(String academicYear) {
		this.academicYear = academicYear;
	}
	public double getMath() {
		return math;
	}
	public void setMath(double math) {
		this.math = math;
	}
	public double getChemistry() {
		return chemistry;
	}
	public void setChemistry(double chemistry) {
		this.chemistry = chemistry;
	}
	public double getPhysic() {
		return physic;
	}
	public void setPhysic(double physic) {
		this.physic = physic;
	}
	@Override
	public String toString() {
		return "Name " + fullName + " Math " + math + " Year " + academicYear;
	}
	
	public double DTB() {
		return ( this.getMath() + this.getChemistry() + this.getPhysic() )/3;
	}
	
}
