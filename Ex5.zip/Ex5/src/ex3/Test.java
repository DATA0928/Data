package ex3;

import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		Student[] students = { new Student("123", "van b", "2004", 6.0, 0, 0),
				new Student("456", "van a", "2005", 2.0, 0, 0), new Student("789", "van c", "2006", 9.0, 0, 0) };

		Student[] student = { new Student("123", "van b", "2004", 6.0, 0, 0),
				new Student("456", "van a", "2005", 2.0, 0, 0), new Student("789", "van c", "2006", 9.0, 0, 0) };
		
		Student[] s1 = { new Student("123", "van b", "2004", 6.0, 0, 0),
				new Student("456", "van a", "2001", 2.0, 0, 0), new Student("789", "van c", "2006", 9.0, 0, 0) };

		System.out.println("Mảng trước khi sắp xếp là ");
		System.out.println(Arrays.toString(students));

		ArrayStudent.getArrayStudent_Sort_SelectionSort(students);

		System.out.println("Mảng sau khi sắp xếp là");
		System.out.println(Arrays.toString(students));

		System.out.println("---------------------------");

		System.out.println("Mảng trước khi sắp xếp là ");
		System.out.println(Arrays.toString(student));

		ArrayStudent.bubbleSort(student);

		System.out.println("Mảng sau khi sắp xếp là");
		System.out.println(Arrays.toString(students));
		
		System.out.println("---------------------------");

		System.out.println("Mảng trước khi sắp xếp là ");
		System.out.println(Arrays.toString(s1));

		ArrayStudent.insertionSort(s1);

		System.out.println("Mảng sau khi sắp xếp là");
		System.out.println(Arrays.toString(s1));

	}
}
