package ex3;

import java.util.Objects;

public class ArrayStudent {
//	-id: String
//	-name:String
//	-arrayStudent: Student[ ]
//	+ getArrayStudent_Sort_SelectionSort() :
//	Student[ ]
//	+ getArrayStudent_Sort_BubbleSort() :
//	Student[ ]
//	+ getArrayStudent_Sort_InsertSort() :
//	Student[ ]

	private String id;
	private String name;
	Student[] Students;

	public ArrayStudent(String id, String name, Student[] students) {
		this.id = id;
		this.name = name;
		Students = students;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Student[] getStudents() {
		return Students;
	}

	public void setStudents(Student[] students) {
		Students = students;
	}

	public static void getArrayStudent_Sort_SelectionSort(Student[] array) {
		for (int i = 0; i < array.length - 1; i++) {
			for (int j = i + 1; j < array.length; j++) {
				if (array[i].getMath() > array[j].getMath()) {
					Student temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
	}
	
	public static void bubbleSort(Student[] array) {
	    int n = array.length;
	    for (int i = 0; i < n - 1; i++) {
	        for (int j = 0; j < n - i - 1; j++) {
	            // So sánh chuỗi tên (sử dụng phương thức compareTo)
	            if (array[j].getFullName().compareTo(array[j + 1].getFullName()) > 0) {
	                // Swap array[j] and array[j + 1]
	                Student temp = array[j];
	                array[j] = array[j + 1];
	                array[j + 1] = temp;
	            }
	        }
	    }
	}

	
	public static void insertionSort(Student[] array) {
	    for (int i = 1; i < array.length; i++) {
	        Student key = array[i];
	        int j = i - 1;
	        
	        // Lấy năm học của sinh viên tại vị trí i
	        String temp = key.getAcademicYear();

	        // Di chuyển các phần tử của mảng lớn hơn temp về sau một vị trí
	        while (j >= 0 && array[j].getAcademicYear().compareTo(temp) > 0) {
	            array[j + 1] = array[j];
	            j--;
	        }
	        
	        // Gán temp vào vị trí đúng trong mảng
	        array[j + 1] = key;
	    }
	}

}
