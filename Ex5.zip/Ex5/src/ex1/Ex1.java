package ex1;

public class Ex1 {
	public static int linearSearch(int [] array , int target) {
		for (int i = 0 ; i < array.length ; i++) {
			if(array[i] == target) {
				return i;
			}
		}
		return -1;
	}
	
	public static boolean binarySearch (int [] arr , int target , int low , int hight) {
		if(low > hight) {
			return false;
		}else {
			int mid = (low + hight) / 2;
			if(target == arr[mid]) {
				return true;
			}else if (target < arr[mid]) {
				return binarySearch(arr, target, low, mid - 1);
			}else {
				return binarySearch(arr, target, mid + 1, hight);
			}
		}
	}
	
	public static void main(String[] args) {
		int [] arr = {30,42,50,55,61,69,72,90};
		int n = 69;
		System.out.println("Số " + n + " tồn tại trong mảng ở vị trí: " + linearSearch(arr, n));
		System.out.println("Số " + n + " có trong mảng: " + binarySearch(arr, 69, 0, 7));
	}
}
