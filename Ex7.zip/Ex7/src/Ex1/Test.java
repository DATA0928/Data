package Ex1;
import java.util.Arrays;
import java.util.ListIterator;

public class Test {
	public static void main(String[] args) {
		String [ ] array = {"son","dat","tuan","phu"};
		ListIterator list = Arrays.asList(array).listIterator();
		
	
		System.out.println(list.hasNext());
		System.out.println(list.next());
		
		System.out.println(list.hasNext());
		System.out.println(list.next());
		System.out.println(list.next());
		System.out.println(list.next());
		
		System.out.println(list.hasNext());
		System.out.println(list.hasPrevious());
		System.out.println(list.previous());
		System.out.println(list.previous());
	}
}
