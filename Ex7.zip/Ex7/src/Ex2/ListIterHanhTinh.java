package Ex2;

import java.util.Arrays;
import java.util.ListIterator;
import java.util.Random;

public class ListIterHanhTinh {
	private static ListIterator<HanhTinh> li;
	private int size = 0;
	public ListIterHanhTinh(HanhTinh[] arr) {
		this.li = Arrays.asList(arr).listIterator();
		this.size = arr.length;
	}
	
	public HanhTinh findInfoPlanetTV(String tenTV) {
		HanhTinh result = null;
		while(li.hasNext()) {
			HanhTinh tmp = li.next();
			if(tmp.getTenTV().equalsIgnoreCase(tenTV)) {
				result = tmp;
			}
		}
		return result;
	}
	
	public HanhTinh findInfoPlanetTA(String tenTA) {
		HanhTinh result = null;
		while(li.hasNext()) {
			HanhTinh tmp = li.next();
			if(tmp.getTenTA().equalsIgnoreCase(tenTA)) {
				result = tmp;
			}
		}
		return result;
	}
	
	
	public static void refresh() {
		while(li.hasPrevious()) {
			li.previous();
		}
	}

	@Override
	public String toString() {
		refresh();
		String result = "";
		while(li.hasNext()) {
			result += li.next() + "\n";
		}
		return result;
	}
	
	// ý tưởng là cho thằng result nhảy lên vị trí của thằng com
	// để thằng max so sánh với thằng new
	public HanhTinh getPlanet_MaxChuKy() {
		refresh();
		double maxCK = 0.0;
		HanhTinh result = li.next();
		HanhTinh com = null;
		while(li.hasNext()) {
			com = li.next();
			double newCK = result.getChuKy();
			if(maxCK < newCK) {
				maxCK = newCK;
				result = com;
			}
		}
		return result;
	}
	
	public HanhTinh getPlanet_DienTichLonNhat() {
		refresh();
		double max = 0.0;
		HanhTinh result = li.next();
		HanhTinh com = null;
		while(li.hasNext()) {
			com = li.next();
			double newDT = result.getDienTich();
			if(max < newDT) {
				max = newDT;
				result = com;
			}
		}
		return result;
	}
	
	public HanhTinh getPlanet_khoiLuongLonNhat() {
		refresh();
		double max = 0.0;
		HanhTinh result = li.next() ;
		HanhTinh com = null;
		while(li.hasNext()) {
			com = li.next();
			double newKL = result.getKhoiLuong();
			if(max < newKL) {
				max = newKL;
				result = com;
			}
		}
		return result;
	}
	
	
	
	public HanhTinh getRandomPlanet() {
		refresh();
		Random r = new Random();
		int ranNum = r.nextInt(size);
		int step = 0 ;
		HanhTinh result = null;
		while (step < ranNum) {
			if(li.hasNext()) {
				result = li.next();
			}
			step ++;
		}
		return result;
	}
	
	public String soSanhChuKy(HanhTinh h1 , HanhTinh h2) {
		refresh();
		String result = "";
		double cktd = h1.getChuKy();
		double ckhtk = h2.getChuKy();
		if(cktd < ckhtk) {
			result = "nhỏ hơn";
		}else {
			result = "lớn hơn";
		}
		return result;
	}
	
	public static void main(String[] args) {
		HanhTinh tho = new HanhTinh("Sao Thổ", "Saturn", 42.7 * Math.pow(10, 9), 568.46 * Math.pow(10, 24), 10757.7365);
		HanhTinh moc = new HanhTinh("Trái Đất", "Earth", 510.0674202, Math.pow(10, 6), 5973.6 * Math.pow(10, 21));
		HanhTinh thuy = new HanhTinh("Sao Thủy", "Mercury",75*Math.pow(10,6), 330*Math.pow(10, 21), 87.96935);
		HanhTinh hoa = new HanhTinh("Sao Hỏa", "Mars", 144.0*Math.pow(10, 6), 641.85*Math.pow(10, 21), 4335.3545);
		HanhTinh kim = new HanhTinh("Sao Kim", "Venun", 460.0*Math.pow(10, 6), 4868.5*Math.pow(10, 21), 224.70096);
		ListIterHanhTinh hts = new ListIterHanhTinh(new HanhTinh[] {kim,moc,thuy,hoa,tho});
		System.out.println(hts.toString());
		hts.refresh();
		System.out.println(hts.findInfoPlanetTA("Earth"));
		hts.refresh();
		System.out.println(hts.findInfoPlanetTV("Sao Kim"));
		System.out.println("----------");
		System.out.println(hts.getPlanet_DienTichLonNhat());
		System.out.println(hts.getPlanet_khoiLuongLonNhat());
		System.out.println(hts.getPlanet_MaxChuKy());
		System.out.println("----------");
		System.out.println(hts.getRandomPlanet());
		System.out.println("----------");
		System.out.println(hts.soSanhChuKy(moc, kim));
		System.out.println(hts.soSanhChuKy(moc, thuy));
		System.out.println(hts.soSanhChuKy(moc, hoa));
		System.out.println(hts.soSanhChuKy(moc, tho));
	}
	
}
