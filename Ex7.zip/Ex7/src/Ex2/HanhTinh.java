package Ex2;

public class HanhTinh {
	private String tenTV;
	private String tenTA;
	private double chuKy;
	private double dienTich;
	private double khoiLuong;

	public HanhTinh(String tenTV, String tenTA, double chuKy, double dienTich, double khoiLuong) {
		super();
		this.tenTV = tenTV;
		this.tenTA = tenTA;
		this.chuKy = chuKy;
		this.dienTich = dienTich;
		this.khoiLuong = khoiLuong;
	}

	@Override
	public String toString() {
		return "HanhTinh [tenTV-" + tenTV + ", tenTA-" + tenTA + ", chuKy-" + chuKy + ", dienTich-" + dienTich
				+ ", khoiLuong-" + khoiLuong + "]";
	}

	public String getTenTV() {
		return tenTV;
	}

	public void setTenTV(String tenTV) {
		this.tenTV = tenTV;
	}

	public String getTenTA() {
		return tenTA;
	}

	public void setTenTA(String tenTA) {
		this.tenTA = tenTA;
	}

	public double getChuKy() {
		return chuKy;
	}

	public void setChuKy(double chuKy) {
		this.chuKy = chuKy;
	}

	public double getDienTich() {
		return dienTich;
	}

	public void setDienTich(double dienTich) {
		this.dienTich = dienTich;
	}

	public double getKhoiLuong() {
		return khoiLuong;
	}

	public void setKhoiLuong(double khoiLuong) {
		this.khoiLuong = khoiLuong;
	}

	public static void main(String[] args) {
		HanhTinh moc = new HanhTinh("Trái Đất", "Earth", 510.0674202, Math.pow(10, 6), 5973.6 * Math.pow(10, 21));
		HanhTinh tho = new HanhTinh("Sao Thổ", "Saturn", 42.7 * Math.pow(10, 9), 568.46 * Math.pow(10, 24), 10757.7365);
		HanhTinh thuy = new HanhTinh("Sao Thủy", "Mercury",75*Math.pow(10,6), 330*Math.pow(10, 21), 87.96935);
		HanhTinh hoa = new HanhTinh("Sao Hỏa", "Mars", 144.0*Math.pow(10, 6), 641.85*Math.pow(10, 21), 4335.3545);
		HanhTinh kim = new HanhTinh("Sao Kim", "Venun", 460.0*Math.pow(10, 6), 4868.5*Math.pow(10, 21), 224.70096);

		System.out.println(kim.toString());
		System.out.println(moc.toString());
		System.out.println(thuy.toString());
		System.out.println(hoa.toString());
		System.out.println(tho.toString());
	}
}
