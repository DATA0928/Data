package caesarcipher;

public class CaesarCipher {
	public char [] alphabet = new char [26];

	public CaesarCipher(char[] alphabet) {
		super();
		this.alphabet = alphabet;
		createAlphabet();
	}
	
	public void createAlphabet() {
		for (int i = 0 ; i < 26 ; i++) {
			alphabet[i] = (char) ('A' + i);
		}
	}

	public String encrypt(String text) {
		String result = "";
		for (int i =0 ; i < text.length(); i++) {
			
		}
	}
	
	public char encryptChar(char c) {
		return (char)
	}
	
	public int getIndexOfAlphabet(char c) {
		int index = -1;
		for (int i = 0 ; i < alphabet.length ; i++) {
			if(alphabet[i] == c) {
				index = i;			
			}
			
		}
		return index;
	}

}

