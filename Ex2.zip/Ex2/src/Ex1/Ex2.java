package Ex1;

public class Ex2 {
	public static String decToBi(int decNum) {
		if(decNum ==1) {
			return "1";
		}else {
			return "" + decToBi(decNum/2) + (decNum%2) ;
		}
	}
	public static void main(String[] args) {
		int num = 11;
		System.out.println("Hệ nhị phân của " + num + " là " + decToBi(num));
	}
}

   