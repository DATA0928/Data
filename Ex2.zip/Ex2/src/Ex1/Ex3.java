package Ex1;

public class Ex3 {
	public static int binToDec(String binaryString) {
		int decimal = 0;
		int binaryLength = binaryString.length();

		for (int i = 0; i < binaryLength; i++) {
		char digit = binaryString.charAt(i);
		if (digit == '1') {
		decimal += Math.pow(2, binaryLength - 1 - i);
		} else if (digit != '0') {
		throw new IllegalArgumentException("Chuỗi không phải là chuỗi nhị phân hợp lệ");
		}
		}

		return decimal;
		}
	
	public static void main(String[] args) {
		String num = "1011";
		System.out.println("Hệ thập phân của " + num + " là " + binToDec(num) );
	}
}
