package ex;

public class SumEx18 {
	public static double sum(double n) {
		// kinh nghiệm chia phân số nhớ để double chứ đừng sài int.
		double result = 0;
		if (n == 1) {
			result = 1.0;
		} else {
			result += 1.0 / n + sum(n - 1);
		}
		return result;

	}

	public static void main(String[] args) {
		double n = 3;
		System.out.println("Tổng 1/n với n = " + n + " là: " + sum(n));
	}

}
