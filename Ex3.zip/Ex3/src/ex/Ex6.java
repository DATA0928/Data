package ex;

public class Ex6 {
	public static int tichCacChuSo(int n) {
		if(n < 10) {
			return n;
		}else {
			return n%10 * tichCacChuSo(n/10);
		}
	}
	public static void main(String[] args) {
		int n = 125;
		System.out.println("Tích các chữ số nguyên dương với n = " + n + " là " + tichCacChuSo(n));
	}
}
