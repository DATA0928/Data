package ex;

public class Ex8 {

	public static int soLuongChuSoChan(int n) {
		if (n == 0) {
			return 0;
		}

		int count = kiemTraSoLe(n % 10) ? 1 : 0;
		return count + soLuongChuSoChan(n / 10);
	}

	public static boolean kiemTraSoLe(int n) {
		return n % 2 == 0;      // !=0 là lẽ
	}							// ==0 là chẵn 

	public static void main(String[] args) {
		int n = 1234567;
		System.out.println("Số lượng chữ số chẵn của " + n + " là: " + soLuongChuSoChan(n));
	}

}
