package ex;

public class Ex24 {
	public static int tich(int n) {
		if(n==1) {
			return 1;
		}else {
			return n*tich(n-1);
		}
	}
	public static void main(String[] args) {
		int n = 3;
		System.out.println("Tích từ 1 đến n với n = " + n + " là " + tich(n));
	}
}
