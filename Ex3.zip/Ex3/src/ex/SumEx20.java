package ex;

public class SumEx20 {
	public static double sum(int n) {
	    if (n == 0) {
	        return 1.0;
	    } else {
	        return 1.0 / (2 * n + 1) + sum(n - 1);
	    }
	}
	public static void main(String[] args) {
		int n = 3;
		System.out.println("Tổng 1/(2n+1) với n = " + n + " là " + sum(n));
	}
}
