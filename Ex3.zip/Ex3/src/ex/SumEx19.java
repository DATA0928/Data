package ex;

public class SumEx19 {
	public static double sum(double n) {
		double result = 0;
		if(n==1) {
			result = 0.5;
		}else {
			result += 1.0/(2*n) + sum(n-1);
		}
		return result;
	}
	
	public static void main(String[] args) {
		double n = 3;
		System.out.println("Tổng 1/2n với n = " + n + " là " + sum(n) );
	}
}
