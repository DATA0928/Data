package ex;

public class Ex26 {
	public static int tich26(int n) {
		if(n == 1) {
			return 1;
		}else {
			return Ex24.tich(n) + tich26(n-1);
		}
	}
	
	public static void main(String[] args) {
		int n = 3;
		System.out.println("Tích với n = " + n + " là " + tich26(n));
	}
}
