package ex;

public class Ex12 {
	public static int timChuSoLonNhat(int n) {
	    if (n < 10) {
	        return n;
	    } else {
	        int lastDigit = n % 10;
	        int maxDigitInRest = timChuSoLonNhat(n / 10);

	        return Math.min(lastDigit, maxDigitInRest);
	    }
	}

	public static void main(String[] args) {
	    int n = 123985;
	    System.out.println("Chữ số lớn nhất của " + n + " là: " + timChuSoLonNhat(n));
	}
}
