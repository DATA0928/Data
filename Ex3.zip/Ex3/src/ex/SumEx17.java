package ex;

public class SumEx17 {
	public static int sum(int n) {
		int result = 0;
		if(n==1) {
			result = 1;
		}else {
			result += Math.pow(n,2) + sum(n-1);
		}
		return result;
	}
	
	public static void main(String[] args) {
		int n = 3;
		System.out.println("Tổng bình phương các phần tử với n = " + n + " là: " + sum(n) );
	}
}
