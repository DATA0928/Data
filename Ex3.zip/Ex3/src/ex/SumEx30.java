package ex;

public class SumEx30 {
	public static double sum(double n) {
		if (n == 1) {
			return 1.0;
		} else {
			return 1.0 / sum1(n) + sum(n - 1);
		}
	}

	public static double sum1(double n) {

		if (n == 1) {
			return 1;
		} else {
			return n + sum(n - 1);
		}

	}
	
	public static void main(String[] args) {
		double n = 2;
		System.out.println("Tổng các phần tử với n = " + n + " là " + sum(n));
	}
}
