package ex;

public class Ex9 {
	public static int tichCacChuSoLe(int n) {
		int result = 1;
		if(kiemTraSoLe(n) == true) {
			if(n<10) {
				result = n;
			}else {
				result *= n%10 * tichCacChuSoLe(n/10);
			}
		}
		return result;
	}
	public static boolean kiemTraSoLe(int n) {
	    return n % 2 != 0;
	}
	
	public static void main(String[] args) {
		int n = 257;
		System.out.println("Tích các chữ số lẻ với n = " + n + " là " + tichCacChuSoLe(n));
	}
}
