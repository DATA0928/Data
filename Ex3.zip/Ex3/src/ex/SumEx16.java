package ex;

public class SumEx16 {
	public static int sum(int n) {
		int result = 0;
		if(n==1) {
			result = 1;
		}else {
			result += n + sum(n-1);
		}
		return result;
	}
	
	public static void main(String[] args) {
		int n = 3;
		System.out.println("Tổng của n = " + n + " là " + sum(n) );
	}
}
