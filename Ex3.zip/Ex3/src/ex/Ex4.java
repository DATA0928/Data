package ex;

public class Ex4 {
	public static int demChuSo(int n) {
		if (n < 10) {
			return 1;
		} else {
			return 1 + demChuSo(n / 10);
		}
	}

	public static void main(String[] args) {
		int n = 12345;
		System.out.println("Số lượng chữ số của " + n + " là: " + demChuSo(n));
	}

}
