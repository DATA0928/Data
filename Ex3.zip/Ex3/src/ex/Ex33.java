package ex;

public class Ex33 {
	public static int largestOddDivisor(int n) {
	    if (n % 2 == 0) {
	        return largestOddDivisor(n / 2);
	    } else {
	        return n;
	    }
	}

	public static void main(String[] args) {
	    int n = 100; 
	    int result = largestOddDivisor(n);
	    System.out.println("Ước số lẻ lớn nhất của " + n + " là: " + result);
	}

}
