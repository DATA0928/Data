package ex;

public class Ex7 {
	
	public static int soLuongChuSoLe(int n) {
	    if (n == 0) {
	        return 0;
	    }

	    int count = kiemTraSoLe(n % 10) ? 1 : 0;
	    return count + soLuongChuSoLe(n / 10);
	}
	
	

	public static boolean kiemTraSoLe(int n) {
	    return n % 2 != 0;
	}

	
	
	public static void main(String[] args) {
	    int n = 1234567; 
	    System.out.println("Số lượng chữ số lẻ của " + n + " là: " + soLuongChuSoLe(n));
	}

}
