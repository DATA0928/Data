package ex;

public class Ex10 {
	public static String daoNguoc(int n) {

		if (n < 10) {
			return n + "";
		} else {
			return n % 10 + daoNguoc(n / 10) + "";
		}

	}
	
	public static void main(String[] args) {
		int n = 125;
		System.out.println("Chữ số đảo ngược với n = " + n + " là " + daoNguoc(n));
	}
}
