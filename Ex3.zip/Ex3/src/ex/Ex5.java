package ex;

public class Ex5 {
	public static int tongCacChuSo(int n) {
		if( n < 10) {
			return n;
		}else {
			return n%10 + tongCacChuSo(n/10);
		}
	}
	public static void main(String[] args) {
		int n = 125;
		System.out.println("Tổng các chữ số nguyên dương với n = " + n + " là " + tongCacChuSo(n));
	}
}
