package ex;

public class SumEx23 {
	public static double sum (double n) {
		if(n == 0) {
			return 0.5;
		}else {
			return (2*n+1)/(2*n+2) + sum(n-1);
		}
	}
	
	public static void main(String[] args) {
		double n = 2;
		System.out.println("Tổng các phần tử với n = " + n + " là " + sum(n));
	}
}
