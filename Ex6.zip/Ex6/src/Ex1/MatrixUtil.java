package Ex1;

import javax.management.RuntimeErrorException;

public class MatrixUtil {

	public static boolean kiemTraCungKichThuoc(int[][] arr1, int[][] arr2) {
		if ((arr1.length == arr2.length) && arr1[0].length == arr2[0].length) {
			return true;
		}
		return false;
	}

	public static int[][] tongHaiMaTran(int[][] A, int[][] B) {
		if (kiemTraCungKichThuoc(A, B)) {

			int[][] C = new int[A.length][A[0].length];

			for (int i = 0; i < A.length; i++) {
				for (int j = 0; j < A[i].length; j++) {
					C[i][j] = A[i][j] + B[i][j];
				}
			}

			return C;
		} else {
			throw new RuntimeErrorException(new Error("2 ma trận không cùng kích thước"));
		}

	}

	public static void print(int[][] matrix) {
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				System.out.print(matrix[i][j] + "  ");
			}
			System.out.println();
		}
	}

	public static int[][] nhan1SoVoiMaTran(int n, int[][] array) {
		int[][] arr = new int[array.length][array[0].length];
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				arr[i][j] = n * array[i][j];
			}
		}
		return arr;
	}

	public static void tichHaiMaTran(int[][] matrixA, int[][] matrixB) {
		if (matrixA[0].length != matrixB.length) {
			System.out.println("Ma trận không hợp lệ");
		} else {
			int[][] matrixC = new int[matrixA.length][matrixB[0].length];

			for (int i = 0; i < matrixA.length; i++) {
				for (int j = 0; j < matrixB[0].length; j++) {
					for (int k = 0; k < matrixA[0].length; k++) {
						matrixC[i][j] += matrixA[i][k] * matrixB[k][j];
					}
				}
			}
			print(matrixC);
		}
	
		

	}

	public static int[] getColumn(int [][] array, int columnIndex) {
		int [] arr = new int [array.length];
		for (int i = 0 ; i< array.length ; i++) {
			arr[i] = array[i][columnIndex];
		}
		return arr;
	}
	
	public static int getSize(int [][] array) {
		int size =0;
		for (int i = 0 ; i < array.length ; i++) {
			size += array[i].length;
		}
		return size;
	}
	
	public static boolean getSearch (int [][] array , int target) {
		for (int i = 0 ; i < array.length ; i ++) {
			for (int j = 0 ; j < array[i].length ; j++) {
				if(array[i][j] == target) {
					return true;
				}
			}
			
		}
		return false;
	}
	
	public static double avg (int [][] array) {
		double n = 0.0;
		for (int i = 0 ; i < array.length ; i++) {
			for (int j = 0 ; j < array[i].length ; j++) {
				n += array[i][j];
			}
		}
		return n/getSize(array);
	}
	
	public static String toString (int [][] array) {
		String st = "";
		for (int i = 0 ; i< array.length ; i++) {
			for (int j = 0 ; j < array[i].length ; j++) {
				st = st + array[i][j]  + "  " ;
			}
			st = st + "\n";
		}
		return st;
	}
	
	public static void main(String[] args) {
		int[][] mang1 = { { 1, 2, 3, 4 }, { 4, 5, 6, 5 }, { 7, 8, 9, 10 } };
		int[][] mang2 = { { 10, 11, 8, 12 }, { 13, 1, 14, 15 }, { 3, 16, 17, 18 } };

		int[][] arr1 = { { 1, 2, 3 }, { 3, 4, 5 }, { 6, 7, 8 } };
		int[][] arr2 = { { 0, 2, 3 }, { 3, 0, 5 }, { 6, 1, 8 } };

		int n = 2;
		
		System.out.println(toString(mang1));
		System.out.println("+");
		System.out.println(toString(mang2));
		System.out.println("=");
		System.out.println(toString(tongHaiMaTran(mang1, mang2)));

		System.out.println("-----------");

		System.out.println(n + " x ");
		System.out.println();
		System.out.println(toString(arr1));
		System.out.println("=");
		System.out.println(toString(nhan1SoVoiMaTran(n, arr1)));

		System.out.println("-----------");

		System.out.println("Tích 2 ma trận");
		System.out.println(toString(arr1));
		System.out.println("x");
		System.out.println(toString(arr2));
		System.out.println("=");
		tichHaiMaTran(arr1, arr2);
	
	}

}
