package Ex2;

import java.util.Random;

public class MineSweeper {
	private int rows;
	private int columns;
	private int numOfBooms;
	private int[][] matrix;
	public MineSweeper(int rows, int columns, int numOfBooms, int[][] matrix) {
		this.rows = rows;
		this.columns = columns;
		this.matrix = new int[this.rows][this.columns];
		this.numOfBooms = numOfBooms;
		this.createRandomBoomsMatrix();
	}
	private void createRandomBoomsMatrix() {
		int tmp = 0;
		while(tmp < numOfBooms) {
			setUpABoom();
			tmp++;
		}
	}
	private void setUpABoom() {
		int xRan = new Random().nextInt(rows);
		int yRan = new Random().nextInt(columns);
		if(matrix[xRan][yRan] == -1) {
			setUpABoom();
		}else {
			matrix[xRan][yRan] = -1;
		}
	}
	public String toString() {
		String result = "";
		for (int i = 0; i < this.rows; i++) {
			for (int j = 0; j < this.columns; j++) {
				result += matrix[i][j] + "\t";
			}
			result += "\n";
		}
		return result;
	}
	public void solutionBoomMatrix() {
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < columns; col++) {
				if(matrix[row][col] != -1) {
					matrix[row][col] = countBoomAround(row, col);
				}
			}
		}
	}
	private int countBoomAround(int x, int y) {
	    int result = 0;
	    for (int xbegin = x - 1; xbegin < x + 2; xbegin++) {
	        for (int ybegin = y - 1; ybegin < y + 2; ybegin++) {
	            if (xbegin >= 0 && ybegin >= 0 && xbegin < rows && ybegin < columns) {
	                if (matrix[xbegin][ybegin] == -1) {
	                    result++;
	                }
	            }
	        }
	    }
	    return result;
	}
	public static void main(String[] args) {
		int[][] matrix = new int[9][9];
		MineSweeper ms = new MineSweeper(9, 9, 10, matrix);
	    ms.solutionBoomMatrix();
	    System.out.println(ms.toString());
	}
}
