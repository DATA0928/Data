package ex;

public class UCLN {
	public static int run(int a, int b) {
		int result = -1;
		int r = a % b;
		if (r == 0) {
			result = b;
		} else {
			result = run(b, r);
		}
		return result;
	}
	
	public static void main(String[] args) {
		int a = 10;
		int b = 7;
		System.out.println("Ước chung lớn nhất của " + a + " và " + b + " là: " + run(a,b));
	}

}
