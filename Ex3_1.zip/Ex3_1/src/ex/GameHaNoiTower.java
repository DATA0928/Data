package ex;

public class GameHaNoiTower {
	public static String gameHaNoiTower(int n, String beginColumName, String middleColumnName, String endColumName) {
		if (n == 1) {
			return "move form " + beginColumName + " to " + endColumName;
		} else {
			return gameHaNoiTower(n - 1, beginColumName, endColumName, middleColumnName) + "\n"
					+ (" move from " + beginColumName + " to " + endColumName) + "\n"
					+ gameHaNoiTower(n - 1, middleColumnName, beginColumName, endColumName);
		}
	}

	public static void main(String[] args) {
		int n = 3;
		System.out.println("Với "  + n + " đĩa thì số bước dịch chuyển là " + (Math.pow(2, n) -1 ));
		String beginColumName = "A";
		String middleColumnName = "B";
		String endColumName = "C";
		// gameHaNoiTower(n, beginColumName, middleColumnName, endColumName);
		System.out.println(gameHaNoiTower(n, beginColumName, middleColumnName, endColumName));

	}
}
