package ex;

public class FibonacciString {
	public String s = " ";
	
	public FibonacciString(int n) {
		this.s = run(n);
	//	this.s = runRecursive(n);
	}
	
	private String run (int n) {
		String result = "";
		for (int i = 1 ; i < n+1 ; i++) {
			result += fib(i) + " ";
		}
		return result;
	}
	
	private String runRecursive(int n) {
		String result = " ";
		if(n > 0) {
			result += runRecursive(n - 1)+ " " + fib(n);
		}
		return result;
	}
	
	public int fib(int n) {
		int result = 0;
		if(n<1) {
			throw new RuntimeException("Lỗi! n phải lớn hơn 1");
		}else {
			if((n == 1) || (n == 2)){
				result += 1;
			}else {
				result += fib(n-1) + fib(n-2);
			}
		}
		return result;
	}
	
	public String toString() {
		return "Fibonaci [ " + s + "]";
	}
	
	public static void main(String[] args) {
		FibonacciString fi = new FibonacciString(16);
		System.out.println(fi);
	}
	
}
