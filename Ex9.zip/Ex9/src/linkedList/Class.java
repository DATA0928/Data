package linkedList;

import java.util.LinkedList;

public class Class {
	private int id;
	private String name;
	private int year;
	private LinkedList<Student> list = new LinkedList<>();
	private Student student;

	public Class(int id, String name, int year, LinkedList<Student> list) {
		this.id = id;
		this.name = name;
		this.year = year;
		this.list = list;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public LinkedList<Student> getList() {
		return list;
	}

	public void setList(LinkedList<Student> list) {
		this.list = list;
	}

	public void addStudent(Student s1) {
		if (list.isEmpty()) {
			list.add(s1);
		} else if (s1.getAverageMark() <= list.getLast().getAverageMark()) {
			list.addLast(s1);
		} else if (s1.getAverageMark() >= list.getFirst().getAverageMark()) {
			list.addFirst(s1);
		} else if (s1.getAverageMark() >= list.getLast().getAverageMark()
				&& s1.getAverageMark() <= list.getFirst().getAverageMark()) {
			for (int i = 0; i < list.size(); i++) {
				if (s1.getAverageMark() >= list.get(i).getAverageMark()) {
					list.add(i, s1);
					break;
				}
			}
		}
	}

	public LinkedList<Student> getTop() {
		LinkedList<Student> topStudents = new LinkedList<>();

		if (list.size() <= 3) {
			// Nếu danh sách chỉ có 3 đứa thì trả về chính nó
			return list;
		}

		for (int i = 0; i < 3; i++) {
			// lấy ra 3 thằng đầu tiên của danh sách gán nó vào cái danh sách mới 
			// sau đó trả về danh sách mới sau khi đã gán là xong
			topStudents.add(list.get(i));
		}

		return topStudents;
	}

	public LinkedList<Student> removeAvg(double avg) {
		LinkedList<Student> studentsToRemove = new LinkedList<>();

		for (Student student : list) {
			if (student.getAverageMark() < avg) {
				studentsToRemove.add(student);
			}
		}
		// xóa tất cả những thằng nào mà nó có điểm tb nhỏ hơn điểm tb mà ta truyền vào
		//sau đó trả về danh sách sau khi đã cắt là xong
		
		list.removeAll(studentsToRemove); 
		

		return list;
	}
	
	public double findAvg(String name) {
		double result = 0.0;
		for (Student student : list) {
			if(student.getFullName().equalsIgnoreCase(name)) {
				result = student.getAverageMark();
			}
		}
		return result;
	}
	
	public double avgClass(LinkedList<Student> list) {
		double sum = 0.0;
		double result = 0.0;
		for (Student student : list) {
			sum += student.getAverageMark();
		}
		result = sum/list.size();
		return result;
	}

	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Student student : list) {
			sb.append(student).append("\n");
		}
		return sb.toString();
	}

	public static void main(String[] args) {
		LinkedList<Student> list = new LinkedList<Student>();
		Student s1 = new Student(22130235, "Nguyen Chi Son", 4.0);
		Student s2 = new Student(22130236, "Phan Minh Phu", 3.9);
		Student s3 = new Student(22130237, "Nguyen Ha Minh Thu", 3.8);
		Student s4 = new Student(22130238, "Nguyen Thi Ha Tien", 3.7);
		Student s5 = new Student(22130239, "Nguyen Viet Cuong", 3.6);
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		list.add(s5);
		for (Student student : list) {
			String st = "";
			st += student;
			System.out.println(st);
		}

		Class c1 = new Class(123, "DH22DTB", 2022, list);
		
		Student s6 = new Student(22130239,"Nguyen Thi Thu Van", 3.95);
		
		c1.addStudent(s6);
		System.out.println(c1.getTop());
		System.out.println(c1.removeAvg(3.9));	
		System.out.println(c1.findAvg("Nguyen Chi Son"));
		System.out.println(c1.avgClass(list));
	}

}
