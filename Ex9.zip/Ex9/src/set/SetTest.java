package set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SetTest {
	public static void main(String[] args) {
//		Set<String> words = new HashSet<String>(); // HashSet implements Set
//		long totalTime = 0;
//		Scanner in = new Scanner(System.in);
//		while (in.hasNext()) {
//			String word = in.next();
//			long callTime = System.currentTimeMillis();
//			words.add(word);
//			callTime = System.currentTimeMillis() - callTime;
//			totalTime += callTime;
//			System.out.println(words);
//		}
		
//		Set<String> words = new LinkedHashSet<String>(); // HashSet implements Set
//		long totalTime = 0;
//		Scanner in = new Scanner(System.in);
//		while (in.hasNext())
//		{
//		String word = in.next();
//		long callTime = System.currentTimeMillis();
//		words.add(word);
//		callTime = System.currentTimeMillis() - callTime;
//		totalTime += callTime;
//		System.out.println(words);
//		}
//		Set<String> sorter = new TreeSet <String>();
//		sorter.add("huy");
//		sorter.add("Bob");
//		sorter.add("Amy");
//		sorter.add("Carl");
//		sorter.add("A");
//		sorter.add("AA");
//		sorter.add("AAA");
//		sorter.add("a");
//		sorter.add("Aaa");
//		sorter.add("aaa");
//		for (String s : sorter) System.out.println(s);;
	
		
	HashSet<String> hashSet = new HashSet<>();
	LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
	TreeSet<String> treeSet = new TreeSet<>();
	String element1 = "AAA";
	String element2= "Aaa";
	String element3= "AAa";
	String element4= "aaa";
	
	// ------------Test Time
	
	long beginHash = System.nanoTime();
	hashSet.add(element1);
	hashSet.add(element2);
	hashSet.add(element3);
	hashSet.add(element4);
	long endHash = System.nanoTime();
	
	System.out.println("hashSet");
	System.out.println("AAA hash code " + element1.hashCode());
	System.out.println("Aaa hash code " + element2.hashCode());
	System.out.println("AAa hash code " + element3.hashCode());
	System.out.println("aaa hash code " + element4.hashCode());
	System.out.println(hashSet);
	System.out.print("Time process   ");
	System.out.println( endHash - beginHash);
	
	
	
	long beginlink = System.nanoTime();
	linkedHashSet.add(element1);
	linkedHashSet.add(element2);
	linkedHashSet.add(element3);
	linkedHashSet.add(element4);
	long endlink = System.nanoTime();
	
	System.out.println("linkedHashSet");
	System.out.println(linkedHashSet);
	System.out.print("Time process   ");
	System.out.println( endlink - beginlink);
	
	
	// Tree set được sắp xếp dựa trên compareTo của comparable hoặc comparator
	long beginTree = System.nanoTime();
	treeSet.add(element1);
	treeSet.add(element2);
	treeSet.add(element3);
	treeSet.add(element4);
	long endTree = System.nanoTime();
	
	System.out.println("treeSet");
	System.out.println(treeSet);
	System.out.println("AAA so sánh với AAa");
	System.out.println(element1.compareTo(element2));
	System.out.println("Aaa so sánh với AAa");
	System.out.println(element2.compareTo(element3));
	System.out.println("AAa so sánh với aaa");
	System.out.println(element3.compareTo(element4));

// về nhà kiểm tra xem hashSet và TreeSet trong java util sắp xếp dựa trên cái nào
	
	System.out.print("Time process   ");
	System.out.println( endTree - beginTree);
	
	
	
	
	
	
	
	
	
	}
}
